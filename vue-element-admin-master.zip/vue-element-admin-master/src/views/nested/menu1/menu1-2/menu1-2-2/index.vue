<template functional>
  <div style="padding:30px;">
    <el-alert :closable="false" title="menu 1-2-2" type="warning" />
  </div>
</template>
